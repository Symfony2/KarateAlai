global using KarateClassLibrary;
